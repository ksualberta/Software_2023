# SPEAR-Webcam-Image-Transfer-Python-
#writing a client and server socket model for recieving and sending data frames. 
